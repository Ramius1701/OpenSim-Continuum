$(function(){
	// References
	var topmenu = $("#topmenu li");
	var members = $("#member-actions li");
	var loading = $("#loading");
	var main_content = $("#main_content");

	// Main menu click events
	topmenu.click(function(event){
		showLoading();
		switch(this.id){
			{MenuItemsArrayBegin}
			case "{MenuItemID}":
		    main_content.load("{MenuItemLocation}" + window.location.search, hideLoading);
				/* main_content.slideUp('swing',  function() {
				    main_content.load("{MenuItemLocation}" + window.location.search, hideLoading);
				    main_content.slideDown();
				}); */

				break;
				{ChildrenMenuItemsArrayBegin}
			case "{ChildMenuItemID}":
				main_content.load("{ChildMenuItemLocation}" + window.location.search, hideLoading);
				break;
				{ChildrenMenuItemsArrayEnd}
				{MenuItemsArrayEnd}
			default:
				// hide loading bar if there is no selected section
				hideLoading();
				break;
		}
		event.stopPropagation();
	});

	// member action events - login
	members.click(function(event){
		//show the loading bar
		//showLoading();
		//load selected section
		switch(this.id){
		 	{MenuItemsArrayBegin}
			case "{MenuItemID}":
		    main_content.load("{MenuItemLocation}" + window.location.search, hideLoading);
				/* main_content.slideUp('swing',  function() {
				    main_content.load("{MenuItemLocation}" + window.location.search, hideLoading);
				    main_content.slideDown();
				}); */

				break;
				{ChildrenMenuItemsArrayBegin}
			case "{ChildMenuItemID}":
				main_content.load("{ChildMenuItemLocation}" + window.location.search, hideLoading);
				break;
				{ChildrenMenuItemsArrayEnd}
				{MenuItemsArrayEnd}
			default:
				//hide loading bar if there is no selected section
				//hideLoading();
				break;
		}
		event.stopPropagation();
	});

	//show loading bar
	function showLoading(){
		loading
			.css({visibility:"visible"})
			.css({opacity:"1"})
			.css({display:"block"})
		;
	}
	//hide loading bar
	function hideLoading(){
		loading.fadeTo(1000, 0);
	};
});

// embedded page content
function continuumPageUrl(location, params=''){
	var query = [];
	params = (params || '').replace(/^[?&]+/, '');
	var existing = (window.location.search || '').replace(/^\?/, '');
	if (params !== '') query.push(params);
	if (existing !== '') query.push(existing);
	return location + (query.length ? '?' + query.join('&') : '');
};

function loadcontent(pageid, params=''){
	var main_content = $("#main_content");
	//load selected page
	switch(pageid){
		{MenuItemsArrayBegin}
			case "{MenuItemID}":
			main_content.load(continuumPageUrl("{MenuItemLocation}", params));
				break;
			{ChildrenMenuItemsArrayBegin}
			case "{ChildMenuItemID}":
				main_content.load(continuumPageUrl("{ChildMenuItemLocation}", params));
				break;
			{ChildrenMenuItemsArrayEnd}
		{MenuItemsArrayEnd}
		default:
			break;
	}
};

// WhiteCore account and administration fragments use this legacy function
// name. Continuum renders those fragments in the main shell, so keep one
// navigation implementation and route the legacy calls through it.
function loadusercontent(pageid, params=''){
	loadcontent(pageid, params);
};

function loadmodalcontent(pageid, params='', title='', static=false){
	var modal_content = $("#modalcontent");
	modal_content.html('');		// clear anything previously loaded

	//load selected page
	switch(pageid){
		{ModalItemsArrayBegin}
			case "{MenuItemID}":
		    modal_content.load(continuumPageUrl("{MenuItemLocation}", params));
				break;
		{ModalItemsArrayEnd}
		default:
			break;
	}

  if (static) {
	  $("#profileModal").modal({
	    backdrop: "static",
	    keyboard: false
	  });
	}
	$("#profileModal").modal("show");
};
